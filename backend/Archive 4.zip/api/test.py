import os

print(os.getenv("DJANGO_SECRET_KEY"))
print(os.getenv('VA_CLIENT_ID'))
print(os.getenv('VA_CLIENT_SECRET'))
print(os.getenv('VA_AUTHORIZATION_URL'))
print(os.getenv('VA_TOKEN_URL'))
print(os.getenv('VA_REDIRECT_URI'))
